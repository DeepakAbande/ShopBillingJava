package project;

public class project {
    public static void main(String[] args) {
        LaunchPage launchPage = new LaunchPage();

    }
}